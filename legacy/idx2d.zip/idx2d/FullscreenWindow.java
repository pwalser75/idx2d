import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.awt.image.BufferStrategy;

public class FullscreenWindow
{    
	private Frame mainframe;
	private BufferStrategy buffer;
	
	public FullscreenWindow(int width, int height)
	{
		GraphicsEnvironment env = GraphicsEnvironment.getLocalGraphicsEnvironment();
		GraphicsDevice device = env.getDefaultScreenDevice();
		GraphicsConfiguration gc = device.getDefaultConfiguration();
            		
		boolean fullscreenSupported = device.isFullScreenSupported();
		if (!fullscreenSupported)
		{
			System.err.println("Fullscreen not supported");
			System.exit(1);
		}
	
		mainframe=new Frame(gc);
		mainframe.setUndecorated(true);
		mainframe.setIgnoreRepaint(true);
		device.setFullScreenWindow(mainframe); 
		
		DisplayMode dm=getBestDisplayMode(device,width,height);
		System.out.println(dm.getWidth()+"x"+dm.getHeight()+"  ["+dm.getBitDepth()+" bit]");
		device.setDisplayMode(dm);
		
		mainframe.createBufferStrategy(2);
		buffer = mainframe.getBufferStrategy();
	}
	
	public Graphics getGraphics()
	{
		return buffer.getDrawGraphics();
	}
	
	public Dimension getSize()
	{
		return mainframe.getSize();
	}
	
	public Frame getFrame()
	{
		return mainframe;
	}
	
	public void show()
	{
		buffer.show();
	}
	
	public static void main(String[] args)
	{
		FullscreenWindow f=new FullscreenWindow(320,240);
		f.getGraphics().setColor(Color.blue);
		f.getGraphics().fillRect(100,100,100,100);
		f.show();
	}
	
	private static DisplayMode getBestDisplayMode(GraphicsDevice device, int width, int height)
	{
		DisplayMode[] BEST_DISPLAY_MODES= new DisplayMode[]
		{
			new DisplayMode(width,height,24,DisplayMode.REFRESH_RATE_UNKNOWN),
			new DisplayMode(width,height,16,DisplayMode.REFRESH_RATE_UNKNOWN),
			new DisplayMode(width,height,8,DisplayMode.REFRESH_RATE_UNKNOWN),
		};
		
		for (int x = 0; x < BEST_DISPLAY_MODES.length; x++)
		{
			DisplayMode[] modes = device.getDisplayModes();
			for (int i = 0; i < modes.length; i++)
			{
				if (modes[i].getWidth() == BEST_DISPLAY_MODES[x].getWidth()
				&& modes[i].getHeight() == BEST_DISPLAY_MODES[x].getHeight()
				&& modes[i].getBitDepth() == BEST_DISPLAY_MODES[x].getBitDepth())
					return BEST_DISPLAY_MODES[x];
			}
		}
		return null;
	}
	
}
	