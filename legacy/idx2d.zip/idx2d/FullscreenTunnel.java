import java.awt.*;
import java.awt.event.*;
import java.applet.*;

import idx2d.*;
import idx2d.grid.*;
import idx2d.physics.Oscillator;

public class FullscreenTunnel implements Runnable
{
	FullscreenWindow w;
	Thread animationThread;
	
	Texture texture;
	Texture output;
	Grid8x8 grid;
	GouraudGridDistorter distorter;
	Oscillator angleOscillator;
	Oscillator speedOscillator;
	Oscillator fovOscillator;
	
	long time=0;
	double pos=0;
	boolean speedup=false;	
	long speedtime;
	long speedintervall=30000;
	
	public static void main(String[] args)
	{
		try
		{
			int w=Integer.parseInt(args[0]);
			int h=Integer.parseInt(args[1]);
			new FullscreenTunnel(w,h);
		}
		catch(Exception e)
		{
			new FullscreenTunnel(400,300);
		}
	}
	
	public FullscreenTunnel(int width,int height)
	{
		w=new FullscreenWindow(width,height);
		w.show();
		
		texture=new Texture("textures/tunnel.jpg");
		
		grid=new Grid8x8(w.getSize().width,w.getSize().height);
		distorter=new GouraudGridDistorter(w.getSize().width,w.getSize().height);
		
		angleOscillator=new Oscillator(20,60,50000);
		
		w.getFrame().addMouseListener(new MouseAdapter()
		{
			public void mousePressed(MouseEvent e)
			{
				if (speedup) return;
				speedtime=0;
				speedOscillator=new Oscillator(0.016,0.42,speedintervall);
				fovOscillator=new Oscillator(90,179.99,speedintervall);
				speedup=true;
			}
		});
		
		start();
	}
	
	public void run()
	{
		while(true)
		{
			apply();
			blitTexture(output);
		}
	}
	
	public void apply()
	{
		time+=50;
		double angle=angleOscillator.getValue(time);
		if (speedup)
		{
			pos+=speedOscillator.getValue(speedtime);
			speedtime+=50;
			if (speedtime>speedintervall) speedup=false;
		}
		else pos+=0.016;
		double fov=speedup ? fovOscillator.getValue(speedtime) : 90;
		
		grid=Tunnel.create(grid,fov,angle,pos,0.5,1);
		output=distorter.distort(texture,grid);

	}

	public void start()
	{
		animationThread=new Thread(this,"Animation Thread");
		animationThread.start();
	}
	
	public void stop()
	{
		animationThread.stop();
		animationThread=null;
	}
	
	public void blitTexture(Texture t)
	{
		Graphics g=w.getGraphics();
		if ((t!=null) && (g!=null)) g.drawImage(t.getImage(),0,0,null);
		w.show();
	}
			
}
