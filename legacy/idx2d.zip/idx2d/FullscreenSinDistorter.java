import java.awt.*;
import java.awt.event.*;
import java.applet.*;

import idx2d.*;
import idx2d.grid.*;
import idx2d.physics.Oscillator;

public class FullscreenSinDistorter implements Runnable
{
	FullscreenWindow w;
	Thread animationThread;
	
	Texture texture;
	Texture output;
	Grid8x8 grid;
	GridDistorter distorter;
	long time=0;
	Oscillator angleOscillator;
	
	public static void main(String[] args)
	{
		new FullscreenSinDistorter();
	}
	
	public FullscreenSinDistorter()
	{
		w=new FullscreenWindow(512,384);
		w.show();
		
		texture=new Texture("textures/horny.jpg");
		
		grid=new IsoGrid8x8(w.getSize().width,w.getSize().height);
		distorter=new FastGridDistorter(w.getSize().width,w.getSize().height);
		
		angleOscillator=new Oscillator(-480,480,20000);
		
		start();
	}
	
	public void run()
	{
		while(true)
		{
			apply();
			blitTexture(output);
		}
	}
	
	public void apply()
	{
		time+=50;
				
		double angle=angleOscillator.getValue(time);
		
		grid.reset();
		grid=RotoZoomer.rotoZoom(grid,angle,1);
		
		output=distorter.distort(texture,SinDistorter.distort(grid,0.04,3,0,0.04,2,0));

	}

	public void start()
	{
		animationThread=new Thread(this,"Animation Thread");
		animationThread.start();
	}
	
	public void stop()
	{
		animationThread.stop();
		animationThread=null;
	}
	
	public void blitTexture(Texture t)
	{
		Graphics g=w.getGraphics();
		if ((t!=null) && (g!=null)) g.drawImage(t.getImage(),0,0,null);
		w.show();
	}
			
}
