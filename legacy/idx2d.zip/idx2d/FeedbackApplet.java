import java.awt.*;
import java.applet.*;

import idx2d.*;
import idx2d.filter.*;
import idx2d.grid.*;
import idx2d.physics.Oscillator;

public class FeedbackApplet extends ThreadApplet
{
	Texture output,texture;
	Grid8x8 grid;
	GridDistorter distorter;
	long time=0;
	Oscillator angleOscillator,zoomOscillator;
	Oscillator oscx,oscy,hue;
	int lastx,lasty;
	FastBlur fastBlur;
	boolean useTexture=true;
	
	int halfblock=60;
	
	public void init()
	{
		texture=getTexture("texture");
		grid=new Grid8x8(size().width,size().height);
		distorter=new FastGridDistorter(size().width,size().height);
		zoomOscillator=new Oscillator(0.95,0.98,8000);
		angleOscillator=new Oscillator(-.002,.004,12000);
		oscx=new Oscillator(50+halfblock,size().width-halfblock-50,329);
		oscy=new Oscillator(50+halfblock,size().height-halfblock-50,7777);
		hue=new Oscillator(0,1,20000);
		lastx=(int)oscx.getValue(0);
		lasty=(int)oscy.getValue(0);
		
		texture.resize(size().width,size().height);
		output=new Texture(size().width,size().height);
		fastBlur=new FastBlur(output);
	}
	
	public void run()
	{
		while(true)
		{
			time+=50;
			if (useTexture) mix();
			else paintDots();
			blitTexture(output);
			distort();
			blur();
		}
	}
	
	private void distort()
	{	
		double zoom=zoomOscillator.getValue(time);
		double angle=angleOscillator.getValue(time);
		
		output=distorter.distort(output,SinDistorter.distort(grid,0.01,2,0,0.01,1,100*hue.getValue(time)));
		output=distorter.distort(output,RotoZoomer.rotoZoom(grid,angle,zoom,0.48,0.36));
	}
	
	private void paintDots()
	{
		int color=Color.HSBtoRGB((float)(hue.getValue(time)),1f,0.5f);
		int ybase=(int)oscy.getValue(time);
		int y;
		
		for (int x=size().width;x>=0;x--)
		{
			y=ybase+(int)(20*Math.sin(12*(float)x/oscx.getValue(time)));
			output.pixel[x+y*output.width]=color;
		}
	}
	
	private void mix()
	{
		for (int i=texture.pixel.length-1;i>=0;i--)
			//output.pixel[i]=Color24.mix(output.pixel[i],texture.pixel[i]);
			//output.pixel[i]=Color24.mix(output.pixel[i],Color24.add(texture.pixel[i],(output.pixel[i]&0xFCFCFC)>>2));
			output.pixel[i]=Color24.mix(output.pixel[i],Color24.add(texture.pixel[i],(output.pixel[i]&0xFEFEFE)>>1));
			
			
		
	}
	
	
	private void blur()
	{
		output=fastBlur.blur(output);
	}
	
	public boolean keyDown(Event evt, int key)
	{
		useTexture=!useTexture;
		output=new Texture(size().width,size().height);
		return true;
	}
	
	
	
}
