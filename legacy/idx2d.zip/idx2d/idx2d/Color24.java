package idx2d;

import java.awt.image.DirectColorModel;

public class Color24
{
	private final static int ALPHA=0xFF000000;
	private final static int RED=0xFF0000;
	private final static int GREEN=0xFF00;
	private final static int BLUE=0xFF;
	private final static int MASK=0xFEFEFEFE;
	
	private static int pixel,overflow,r,g,b;
	
	private static DirectColorModel colorModel=new DirectColorModel(24,RED,GREEN,BLUE);
	
	private Color24()
	{
	}

	public static DirectColorModel getColorModel()
	{
		return colorModel;
	}
	
	public static int getColor(int r, int g, int b)
	{
		return ALPHA | (r<<16) | (g<<8) | b;
	}
	
	public static int getRed(int color)
	{
		return (color & RED) >>16;
	}
	
	public static int getGreen(int color)
	{
		return (color & GREEN) >>8;
	}
	
	public static int getBlue(int color)
	{
		return color & BLUE;
	}
	
	public static final int add(int color1, int color2)
	{
		pixel=(color1&0xFEFEFE)+(color2&0xFEFEFE);
		overflow=pixel&0x1010100;
		overflow=overflow-(overflow>>8);
		return ALPHA|overflow|pixel;
	}
	
	public static final int scale(int color, int factor)
	{
		r=(((color>>16)&255)*factor)>>8;
		g=(((color>>8)&255)*factor)>>8;
		b=((color&255)*factor)>>8;
		return ALPHA|(r<<16)|(g<<8)|b;
	}
	
	public static int mix(int oldpixel, int newpixel)
	{
		return ALPHA|(((oldpixel&MASK)>>1)+((newpixel&MASK)>>1));
	}
	
	public static int getGray(int c)
	{
		int brightness=(getRed(c)*3+getGreen(c)*6+getBlue(c))/10;
		return getColor(brightness,brightness,brightness);
	}
	
}