import java.awt.*;
import java.applet.*;

import idx2d.*;
import idx2d.grid.*;
import idx2d.physics.Oscillator;

public class RotoZoomerApplet extends ThreadApplet
{
	Texture texture;
	Texture output;
	Grid8x8 grid;
	GridDistorter distorter;
	Oscillator zoomOscillator;
	Oscillator angleOscillator;
	long time=0;
	
	public void init()
	{
		texture=getTexture("texture");
		
		grid=new Grid8x8(size().width,size().height);
		distorter=new FastGridDistorter(size().width,size().height);
		
		zoomOscillator=new Oscillator(0.24,2,8000);
		angleOscillator=new Oscillator(-480,480,20000);
	}
	
	public void run()
	{
		while(true)
		{
			rotoZoom();
			blitTexture(output);
		}
	}
	
	public void rotoZoom()
	{
		time+=50;
		
		double zoom=zoomOscillator.getValue(time);
		double angle=angleOscillator.getValue(time);
		
		output=distorter.distort(texture,RotoZoomer.rotoZoom(grid,angle,zoom,0.48,0.36));

	}		
}
