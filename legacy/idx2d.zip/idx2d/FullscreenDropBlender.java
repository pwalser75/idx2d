import java.awt.*;
import java.awt.event.*;
import java.applet.*;

import idx2d.*;
import idx2d.grid.*;
import idx2d.physics.Oscillator;

public class FullscreenDropBlender implements Runnable
{
	FullscreenWindow w;
	Thread animationThread;
	
	TextureBlender textureBlender;
	Texture output;
	Grid8x8 grid;
	GridDistorter distorter;
	long time=0;
	Oscillator ampOscillator;
	Oscillator blendOscillator;
	Oscillator wavesOscillator;
	
	public static void main(String[] args)
	{
		try
		{
			int w=Integer.parseInt(args[0]);
			int h=Integer.parseInt(args[1]);
			new FullscreenDropBlender(w,h);
		}
		catch(Exception e)
		{
			new FullscreenDropBlender(400,300);
		}
	}
	
	public FullscreenDropBlender(int width,int height)
	{
		w=new FullscreenWindow(width,height);
		w.show();
		
		textureBlender=new TextureBlender(new Texture("textures/ants.jpg"),new Texture("textures/bot.jpg"));
		
		grid=new IsoGrid8x8(w.getSize().width,w.getSize().height);
		distorter=new FastGridDistorter(w.getSize().width,w.getSize().height);
		
		double interval=20000;
		ampOscillator=new Oscillator(0,0.4,interval);
		wavesOscillator=new Oscillator(9,4,0.8*interval);
		blendOscillator=new Oscillator(0,255,2*interval);
		
		start();
	}
	
	public void run()
	{
		while(true)
		{
			apply();
			blitTexture(output);
		}
	}
	
	public void apply()
	{
		time+=50;
		double amp=ampOscillator.getValue(time);
		int alpha=(int)blendOscillator.getValue(time);
		double waves=wavesOscillator.getValue(time);
		
		grid.reset();
		grid=Drop.create(grid,amp,waves,((double)time)/300d);
		
		output=distorter.distort(textureBlender.blend(alpha),grid);
	}

	public void start()
	{
		animationThread=new Thread(this,"Animation Thread");
		animationThread.start();
	}
	
	public void stop()
	{
		animationThread.stop();
		animationThread=null;
	}
	
	public void blitTexture(Texture t)
	{
		Graphics g=w.getGraphics();
		if ((t!=null) && (g!=null)) g.drawImage(t.getImage(),0,0,null);
		w.show();
	}
			
}
